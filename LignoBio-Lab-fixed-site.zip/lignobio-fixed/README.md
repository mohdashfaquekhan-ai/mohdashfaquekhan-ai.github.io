# LignoBio Lab website — corrected build

This folder contains replacement web files for the public GitHub Pages repository `mohdashfaquekhan-ai.github.io`. Existing image files can remain in the repository.

## Main fixes included
- Fixed broken Publications and Contact navigation/CTA targets.
- Added semantic `<main>`, skip links, `aria-current`, `aria-controls`, keyboard focus styles and Escape/click-outside mobile-menu behaviour.
- Standardised `script.js` with `defer`; removed page-level JavaScript placement inconsistencies.
- Consolidated styling into one shared `style.css`; no page-level inline CSS is required.
- Added canonical URLs, Open Graph/Twitter metadata, favicon declarations and homepage JSON-LD for the lab and Principal Investigator.
- Added `robots.txt`, `sitemap.xml` and `404.html`.
- Improved mobile layouts, contrast and reduced-motion support.
- Reframed the Projects page as Research Programmes & Capabilities while retaining `projects.html`.
- Added recent 2026 LignoBio publications and moved core biomass/biofuel publications before global-health collaborations.
- Replaced the Rafia Shekh “Photo” placeholder with an accessible initials avatar.
- Added practical opportunity-status guidance and a complete institutional postal address.

## Deployment
Replace the corresponding `.html`, `style.css` and `script.js` files in the repository root and add `robots.txt`, `sitemap.xml` and `404.html`. Keep the existing image files (`lignobio-logo.png`, `mohammad-ashfaque.JPG`, `hassan-ali.jpg`, `ayush-saxena.jpg`, `akhtar-hussain.jpg`, `fouziya-parveen.jpg`).
